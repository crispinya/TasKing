import { Component, OnInit } from '@angular/core';

// interface Food {
//   value: string;
//   viewValue: string;
// }

@Component({
  selector: 'app-tarea-personalizada',
  templateUrl: './tarea-personalizada.component.html',
  styleUrls: ['./tarea-personalizada.component.scss']
})
export class TareaPersonalizadaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  // selected = 'option2';

  // foods: Food[] = [
  //   {value: 'steak-0', viewValue: 'Steak'},
  //   {value: 'pizza-1', viewValue: 'Pizza'},
  //   {value: 'tacos-2', viewValue: 'Tacos'}
  // ];

}
