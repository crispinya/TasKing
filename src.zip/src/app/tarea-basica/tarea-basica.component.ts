import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tarea-basica',
  templateUrl: './tarea-basica.component.html',
  styleUrls: ['./tarea-basica.component.scss']
})
export class TareaBasicaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
